#include <iostream>
using namespace std;

int main(){
    // variable
    int age;
    age = 25;
    float pi = 3.14;
    char initial = 'j';
    initial = 'g';
    int a, b;
    a = 5; 
    b = 8;
    int somme = a + b;
    float division = a / b;
    int mutiplication = a * b;
    int modulo = a % b;

    // && => ET || => ou !=> non
    bool res = (5 > 3) || (3 > 10); // true

    int x = 5;
    if( x > 10){ // condition initial
        cout << "x est grand" << endl;
    } else if( x == 5){ // sous condition
        cout << "x est égale à 5" << endl;
    } else { // sinon
        cout << "x est petit" << endl;
    }

    char grade = 'A';
    switch(grade){
        case 'A':
            cout << "excelent"<<endl;
            break;
        case 'B':
            cout << "Bien" << endl;
            break;
        default:
            cout << "essayer encore"<< endl;
    }
    

    // boucles
    // for
    for(int i = 0; i < 5; i++){
        cout << "iteration " << i << endl;
    }

    // while
    int u = 0;
    while (u < 5)
    {
        cout << " valeur de u => " << u << endl;
        u++; // incrementation pour valider le test de sortie
    }

    // do while
    int z = 0;
    do {
        cout << "le Z vaut : " << z << endl;
        z++;
    } while ( z < 5);
    
    
    

    // constante
    const double GRAVITY = 9.81;

    // GRAVITY = 10; mettrait en erreur la compilation

    cout << "il a " << age << " ans !" << endl;
    cout << "son nom commence par " << initial << "  !" << endl;
    return 0;
}