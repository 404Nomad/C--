#include <iostream>

int main() {
    std::cout << "bonne année les cda ! " << std::endl;
    return 0;
}