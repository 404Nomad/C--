#include <sqlite3.h>
#include "sqlite_module.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// init de la connexion
int sqlite_init(SQLiteConnection* con, const char* db_file) {
    int result = sqlite3_open(db_file, &con->db);
    if(result != SQLITE_OK){
        con->lastError = strdup(sqlite3_errmsg(con->db));
        return result;
    }
    con->lastError = NULL;
    return SQLITE_OK;
}

// fermer la connexion
void sqlite_close(SQLiteConnection* con){
    if(con->db){
        sqlite3_close(con->db);
        con->db = NULL;
    }
    if(con->lastError){
        free(con->lastError);
        con->lastError = NULL;
    }
};

// fonction execution de requête
int sqlite_execute(SQLiteConnection* con, const char* sql){
    char* errMessage =  NULL;
    int result = sqlite3_exec(con->db, sql, NULL, NULL, &errMessage);
    if( result != SQLITE_OK){
        con->lastError = strdup(errMessage);
        sqlite3_free(errMessage);
    }
    return result;
};

// fonction read
int sqlite_query(SQLiteConnection* con, const char* sql, 
        int(*callback)(void*, int, char**, char**) , void* data){
    char* errMessage = NULL;
    int result = sqlite3_exec(con->db, sql, callback, data, &errMessage);
    if( result != SQLITE_OK){
        con->lastError = strdup(errMessage);
        sqlite3_free(errMessage);
    }
    return result;
};
