#include <stdio.h>
#include "sqlite_module.h"

int print_callback(void* data, int argc, char** argv, char** colname){
    for(int i = 0; i < argc; i++){
        printf("%s: %s\n", colname[i], argv[i] ? argv[i] : "NULL");
    }
    printf("\n");
    return 0;
}


int main(){
    SQLiteConnection con;

    // init connexion
    if(sqlite_init(&con, "exemple.db") != SQLITE_OK){
        fprintf(stderr, "Erreur : %s\n", con.lastError);
        return -1;
    }

    // creation de la table
    const char* sql = "CREATE TABLE IF NOT EXISTS user("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "firstname TEXT NOT NULL,"
                    "lastname TEXT NOT NULL,"
                    "email TEXT NOT NULL"
                    ");";
    if(sqlite_execute(&con, sql) != SQLITE_OK){
         fprintf(stderr, "Erreur : %s\n", con.lastError);
        return -1;
    }

    sql = "INSERT INTO user(firstname, lastname, email) VALUES "
            "('Alice','Inchain','alice@metal.uk'),"
            "('Ozzy','Osbourn','magicOzz@metal.usa');";
    
    if(sqlite_execute(&con, sql) != SQLITE_OK){
         fprintf(stderr, "Erreur : %s\n", con.lastError);
        return -1;
    }

    sql = "select * from user;";
    if(sqlite_query(&con, sql, print_callback, NULL) != SQLITE_OK){
        fprintf(stderr, "Erreur : %s\n", con.lastError);
    }

    sqlite_close(&con);

    return 0;
}