#ifndef ETUDIANT_H
#define ETUDIANT_H
#include <string>
#include "Personne.h"

using namespace std;

class Etudiant : public Personne {
    private:
        string grade;
        string ecole;
    public:
        Etudiant();
        Etudiant(string grade, string ecole);
        Etudiant(string grade, string ecole, 
                string nom, string prenom, 
                string email, int age);
        ~Etudiant();

        void setGrade(string grade);
        void setEcole(string ecole);
        string getGrade() const;
        string getEcole() const;

        void toString() const;

};

#endif