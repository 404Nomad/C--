#include "Etudiant.h"
#include <iostream>
#include <string>
using namespace std;

Etudiant::Etudiant() : grade(""), ecole(""){} 
Etudiant::Etudiant(string grade, string ecole) : grade(grade), ecole(ecole) {}
Etudiant::Etudiant(string grade, string ecole, 
                string nom, string prenom, 
                string email, int age) : grade(grade), ecole(ecole), 
                        Personne(nom, prenom, email, age) {}

Etudiant::~Etudiant(){}

void Etudiant::setGrade(string grade) { this->grade = grade; }
void Etudiant::setEcole(string ecole) { this->ecole = ecole; }
string Etudiant::getGrade() const { return grade; }
string Etudiant::getEcole() const { return ecole; }

void Etudiant::toString() const {
    cout << "Nom: " << getNom() << " Prenom: " << getPrenom()
        << " grade: " << grade << " ecole: " << ecole  << endl;
}