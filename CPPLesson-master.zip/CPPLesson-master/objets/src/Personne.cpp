#include "Personne.h"
#include <iostream>
#include <string>
using namespace std;

Personne::Personne() : nom(""), prenom(""), email(""), age(0){};
Personne::Personne(string nom, string prenom, string email, int age) 
        : nom(nom), prenom(prenom), email(email), age(age){};
Personne::~Personne(){
        //cout << "test de destruction" << endl;
};

void Personne::setNom(string nom){ this->nom = nom; }
void Personne::setPrenom(string prenom){ this->prenom = prenom; }
void Personne::setEmail(string email){ this->email = email; }
void Personne::setAge(int age){ this->age = age; }

string Personne::getNom() const{ return this->nom; }
string Personne::getPrenom() const{ return this->prenom; }
string Personne::getEmail() const{ return this->email; }
int Personne::getAge() const{ return this->age; }

void Personne::afficheInfo() const {
    cout << "Nom: " << nom 
        << " Prenom: " << prenom 
        << " age: " << age << endl;
}