#include <iostream>
#include <string>
#include <vector>
#include "Personne.h"
#include "Etudiant.h"
using namespace std;

// class Personne {
//     private: // définition des propriétés en privé
//         string nom;
//         string prenom;
//         string email;
//         int age;
    
//     public:

//         Personne() { nom = ""; prenom = ""; email = ""; age = 0; }
//         Personne(string nom, string prenom, string email, int age){
//             this->nom = nom;
//             this->prenom = prenom;
//             this->email = email;
//             this->age = age;
//         }

//         ~Personne() {
//             cout << "l'objet est mort" << endl;
//         }


//         // accesseur 
//         string getNom() { return nom; }
//         string getPrenom() { return prenom; }
//         string getEmail() { return email; }
//         int getAge() { return age; }

//         // mutateur
//         void setNom(string name){ this->nom = name; }
//         void setPrenom(string firstName){ this->prenom = firstName; }
//         void setEmail(string mail){ this->email = mail; }
//         void setAge(int age){ this->age = age; }
//         void setAge(string age, float coeficient){
//             this->age = stoi(age);
//         }

//         void afficheInfo() {
//             cout << "Nom: " << nom 
//                     << " Prenom: " << prenom 
//                     << " age: " << age << endl;
//         }

// };

int main(){

    vector<Personne> carnet;

    Personne p1;
    p1.setNom("Legrand");
    p1.setPrenom("Alexandre");
    p1.setAge(2500);
    p1.setEmail("antique@grec.gc");

    Personne p2("Khan", "Gengis", "atila@bakou.bk", 2000);

    Etudiant e1("licence", "upvd");
    e1.setNom("Toto");
    e1.setPrenom("Adolfe");
    e1.setEmail("toto@toto.fr");
    e1.setAge(23);

    Etudiant e2("master", "paul valerie", "Bridou", "justin", "saucisson@sec.fr", 26);

    //p1.afficheInfo();
    carnet.push_back(p1);
    //p2.afficheInfo();
    carnet.push_back(p2);

    carnet.push_back(e1);
    carnet.push_back(e2);

    for(const auto& pers : carnet){
        pers.afficheInfo();
    }

    return 0;
}