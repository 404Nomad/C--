#ifndef PERSONNE_H
#define PERSONNE_H
#include <string>
using namespace std;

class Personne {
    private:
        string nom;
        string prenom;
        string email;
        int age;

    public:
        Personne();
        Personne(string nom, string prenom, string email, int age);
        ~Personne();

        string getNom() const;
        string getPrenom() const;
        string getEmail() const;
        int getAge() const;

        void setNom(string nom);
        void setPrenom(string prenom);
        void setEmail(string email);
        void setAge(int age);

        void afficheInfo() const;
};

#endif