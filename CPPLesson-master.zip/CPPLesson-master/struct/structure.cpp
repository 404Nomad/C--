#include <iostream>
#include <string>
#include "Triangle.h"

using namespace std;

struct Personne {
    string nom;
    int age;
    float taille;
};

struct Rectangle
{
    int largeur, hauteur; // propriete

    // contructeur
    Rectangle() : largeur(0), hauteur(0) {}
    Rectangle(int largeur, int hauteur) : largeur(largeur), hauteur(hauteur) {}

    int aire() { //methode
        return largeur * hauteur;
    }

    void afficheAire(){ //methode de sortie
        cout << "L'aire du rectangle "<< largeur <<" X "<< hauteur << " = "
            << aire() << " cm2" << endl; 
    }

};

struct Animal
{
    string nom;

    void manger(){
        cout << nom << " mange quelquechose" << endl;
    }
};

struct Chien : public Animal
{
    void aboyer() {
        cout << nom << " aboie" <<endl;
    }
};



int main() {

    Personne p;
    p.nom = "ducobu";
    p.age = 12;
    p.taille = 1.32;

    Rectangle r;
    r.hauteur = 5;
    r.largeur = 7;

    cout << "Nom =>" << p.nom << endl;
    cout << "age =>" << p.age << endl;
    cout << "taille =>" << p.taille << endl;
    r.afficheAire();

    Rectangle r2(8,3);
    r2.afficheAire();
    
    Chien monChien;
    monChien.nom = "Rex";
    monChien.manger();
    monChien.aboyer();

    Animal monChat;
    monChat.nom = "Felix";
    monChat.manger();

    Triangle t1(4,6,8);
    t1.magritt();

    return 0;
}