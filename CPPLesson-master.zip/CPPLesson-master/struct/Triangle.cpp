#include "Triangle.h"
#include <iostream>
using namespace std;

Triangle::Triangle() : cote1(0), cote2(0), cote3(0){}
Triangle::Triangle(int c1, int c2, int c3) : cote1(c1), cote2(c2), cote3(c3){}

void Triangle::magritt() const {
    cout << "ceci est un triangle" << endl;
}