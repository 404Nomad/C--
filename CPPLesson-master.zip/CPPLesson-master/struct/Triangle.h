#ifndef TRIANGLE_H
#define TRIANGLE_H



struct Triangle
{
    int cote1, cote2, cote3;

    Triangle();
    Triangle(int cote1, int cote2, int cote3);

    void magritt() const;
};


#endif