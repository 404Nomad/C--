#include <mysql_driver.h>
#include <mysql_connection.h>
#include <cppconn/statement.h>
#include <cppconn/resultset.h>
#include <cppconn/exception.h>
#include <iostream>

int main(){
    try
    {
        // creation de la connexion
        sql::mysql::MySQL_Driver* driver = sql::mysql::get_mysql_driver_instance();
        std::unique_ptr<sql::Connection> con(driver->connect("tcp://127.0.0.1:3310","cpp","mycpp"));

        // connexion à la base
        con->setSchema("cpp");

        // creation de la table
        std::unique_ptr<sql::Statement> stmt(con->createStatement());
        stmt->execute("CREATE TABLE IF NOT EXISTS user("
                    "id INT PRIMARY KEY AUTO_INCREMENT,"
                    "firstname VARCHAR(50) NOT NULL,"
                    "lastname VARCHAR(50) NOT NULL,"
                    "email VARCHAR(200) NOT NULL"
                    ");");

        // insertion des données
        stmt->execute("INSERT INTO user(firstname, lastname, email) VALUES "
            "('Alice','Inchain','alice@metal.uk'),"
            "('Ozzy','Osbourn','magicOzz@metal.usa');");


        std::unique_ptr<sql::ResultSet> res(stmt->executeQuery("select * from user;"));
        while (res->next())
        {
            std::cout << "ID : " << res->getInt("id") << " | "
                    << "Firstname : " << res->getString("firstname") << " | "
                    << "Lastname : " << res->getString("lastname") << " | "
                    << "Email : " << res->getString("email") << std::endl;
        }
            

    }
    catch(sql::SQLException& e)
    {
        std::cerr << "Erreur MYsql : " << e.what() << std::endl;
    }  

    return 0;
}