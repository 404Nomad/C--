#include <iostream>
using namespace std;


// fonction executer
void incrementer(int* a){
    (*a) += 1;
    cout << "Dans la fonction : " << *a << endl;
}

// fonction executable principale
int main() {
     int x = 10;

     incrementer(&x);
     cout << "après l'appel de la fonciton x vaut : " << x << endl;

    return 0;
}