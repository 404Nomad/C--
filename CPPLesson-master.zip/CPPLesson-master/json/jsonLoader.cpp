#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "json.hpp"

using namespace std;
using json = nlohmann::json;

struct Voiture {
    string marque;
    string model;

    Voiture() : marque(""), model(""){}
    Voiture(string marque, string model) : marque(marque), model(model){}

    void jsonToStruct(const json& j){
        marque = j["marque"];
        model = j["model"];
    }

    void afficher() const {
        cout << "Voiture : marque => "<< marque << ", model => " << model << endl;
    }

    void addJsonArray(json& jsonArray) const{
        json voitureJson = {
            {"marque", marque},
            {"model", model}
        };
        jsonArray.push_back(voitureJson);
    }

};


int main(){

    vector<Voiture> listeVoiture;

    ifstream file("/Users/fauresebastien/24_25/c++/json/db.json");
    if(!file.is_open()){
        cerr << "impossible d'ouvrir le fichier"<< endl;
        return 1;
    }

    json jsonData;
    file >> jsonData;

    auto voitures = jsonData;

    Voiture vv("Wolkswagen", "golf"); // création d'une voiture
    vv.addJsonArray(voitures);  // ajout au tableau json de voiture

    ofstream fileWr("/Users/fauresebastien/24_25/c++/json/db.json");
    if(!fileWr.is_open()){
        cerr << "impossible d'ouvrir le fichier"<< endl;
        return 1;
    }
    fileWr << voitures.dump(4);

    for(const auto& car : voitures){ // parcour du tableau json
        // cout << car["marque"] << endl;
        Voiture v;
        v.jsonToStruct(car); // création des voitures à partir de l'ojet json
        listeVoiture.push_back(v); // ajout des voitures à la liste
    }
    file.close();

    for(const auto& bagnole : listeVoiture){ // parcour de la liste de voiture
        bagnole.afficher();
    }

    return 0;
}