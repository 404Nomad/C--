#include <iostream>
#include "math_utils.h"
using namespace std;

int main() {
    int x = 15, y = 5;
    cout << "somme : " << addition(x,y) << endl;
    cout << "difference : " << soustraction(x,y) << endl;
    cout << "produit : " << multiplication(x,y) << endl;
    cout << "division : " << division(x, y) << endl;
    return 0;
}


