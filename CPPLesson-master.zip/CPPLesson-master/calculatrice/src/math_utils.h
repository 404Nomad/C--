#ifndef MATH_UTILS_H
#define MATH_UTILS_H

int addition(int a, int b);
int soustraction(int a, int b);
int multiplication(int a, int b);
double division(int a, int b);

#endif