#include "math_utils.h"

int addition(int a, int b){
    return a + b;
}

int soustraction(int a, int b){
    return a - b;
}

int multiplication(int a, int b){
    return a * b;
}

double division(int a, int b){
    return a / b;
}