#include <iostream>
#include <sqlite3.h>

using namespace std;

int main(){

    sqlite3* db;

    char* errmsg = nullptr;

    int exit = sqlite3_open("test.db", &db); // ouverture de la base
    if( exit != SQLITE_OK){ // ne trouve pas la base
        cerr << "Erreur sql => " << sqlite3_errmsg(db) << endl;
        return -1;
    } else {
        cout << "Base est ouverte !!" << endl;
    }

    const char* sql = "CREATE TABLE IF NOT EXISTS user("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "firstname TEXT NOT NULL,"
                    "lastname TEXT NOT NULL,"
                    "email TEXT NOT NULL"
                    ");";

    exit = sqlite3_exec(db, sql, nullptr, nullptr, &errmsg);
    if(exit != SQLITE_OK){
        cerr << "Erreur creation table => " << sqlite3_errmsg(db) << endl;
    } else {
        cout << "LA table est bien créée !!" << endl;
    }

    sql =  "INSERT INTO user(firstname, lastname, email) VALUES "
            "('Alice','Inchain','alice@metal.uk'),"
            "('Ozzy','Osbourn','magicOzz@metal.usa');";
    
    exit = sqlite3_exec(db, sql, nullptr, nullptr, &errmsg); // execution de la requete
    if( exit != SQLITE_OK){
        cerr << "Erreur d'insertion => " << errmsg << endl;
    }

    sql = "SELECT * FROM user;";
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);

    cout << "Liste des utilisateurs :" << endl;
    while (sqlite3_step(stmt) == SQLITE_ROW) 
    {
        cout << "ID : " << sqlite3_column_int(stmt, 0) << " | "
                << "Firstname : " << sqlite3_column_text(stmt, 1) << " | "
                << "Lastname : " << sqlite3_column_text(stmt, 2) << " | "
                << "Email : " << sqlite3_column_text(stmt, 3) << endl;
    }

    sqlite3_finalize(stmt);

    sqlite3_close(db);

    return 0;
}