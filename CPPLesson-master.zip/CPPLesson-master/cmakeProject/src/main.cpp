#include <iostream>
using namespace std;

int main(){
    cout <<  "un programme compiler par make" << endl;
    return 0;
}