#include <iostream>
#include <curl/curl.h>
#include "json.hpp"

using namespace std;

// alias json
using json = nlohmann::json;

// Fonction callback pour gére les donnés reçues
size_t WriteCallBack(void* contents, size_t size, size_t nmemb, void* userp){
    ((string*) userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

int main() {
    CURL* curl;
    CURLcode res;

    string readBuffer;
    string apiKey = "3287ca27-26a6-4a61-8b19-bf0d5602df29";

    curl = curl_easy_init();
    if(curl){

        struct curl_slist* headers = NULL;
        headers = curl_slist_append(headers, ("Authorization: " + apiKey ).c_str());
        headers = curl_slist_append(headers, "Content-Type: application/json");

        curl_easy_setopt(curl, CURLOPT_URL, "https://api.balldontlie.io/v1/teams");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallBack);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);

        // passage de paramettre pour le post
        // curl_easy_setopt(curl, CURLOPT_POSTFIELDS, "key1=value1&key2=value2");

        res = curl_easy_perform(curl);
        if (res != CURLE_OK){
            cerr << "CURL error : " << curl_easy_strerror(res) << endl;
        } else {
            try
            {
                json response = json::parse(readBuffer);
                cout << "Reponse json : " << response.dump(4) << endl;
            }
            catch(const std::exception& e)
            {
                cerr << "Erreur de parsing json" << e.what() << '\n';
            }
            
        }
        // nettoyage
        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);
    }
    return 0;
}