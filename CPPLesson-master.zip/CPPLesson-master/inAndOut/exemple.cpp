#include <iostream>
using namespace std;

int main(){
    string nom; // déclaration d'une variable

    cout << "Quel est votre nom ? "; 
    cin >> nom;

    cout << "Bonjour " << nom << " !" << endl;

    return 0;

}